package com.hcl.org;

import java.util.*;
import java.util.stream.*;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.org.entity.Order;
import com.hcl.org.repository.OrderRepository;

@SpringBootApplication
@RestController
@RequestMapping("/orders")
public class CatalogServiceApplication {

	@Autowired
	private OrderRepository orderRepository;
	
	@PostConstruct
	public void initOrderTable() {
		orderRepository.saveAll(Stream.of(new Order("mobile","electronics","white",20000),
				new Order("T-Shirt","cloths","black",2000),
				new Order("Shirt","cloths","white",7000),
				new Order("Ball","play","brown",2000)
				).collect(Collectors.toList()));
	}
	@GetMapping
	public List<Order> getOrders(){
		return orderRepository.findAll();
	}
	
	@GetMapping("/{category}")
	public List<Order> getOrdersByCategory(@PathVariable String category){
		return orderRepository.findByCategory(category);
		
	}
	public static void main(String[] args) {
		SpringApplication.run(CatalogServiceApplication.class, args);
	}

}
