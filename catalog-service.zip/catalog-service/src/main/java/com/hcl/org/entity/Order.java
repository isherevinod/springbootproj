package com.hcl.org.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="ORDER_TB")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Order {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private String category;
	private String color;
	private double price;
	
	public Order( String name,String category,String color,double price) {
		this.name=name;
		this.category=category;
		this.color=color;
		this.price=price;
	}

}
