package com.hcl.org.repository;

import com.hcl.org.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;;

public interface OrderRepository extends JpaRepository<Order,Integer> {

}
