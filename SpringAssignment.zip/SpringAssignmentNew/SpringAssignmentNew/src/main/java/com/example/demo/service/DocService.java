package com.example.demo.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Doc;
import com.example.demo.repository.DocRepository;

@Service
public class DocService {
	@Autowired
   private DocRepository docRepository;

	 public Doc saveFile(MultipartFile file) throws IOException {
	 int m=39;
	 int n=8;
	 int p=24;
	 int count=1;
	 int count1=0;
	 String docname = null ;
	 long docnumber = 0;
	 String doctype = null;
	String doc1 = new String(file.getBytes());
	Doc d=new Doc();
	int i = 0;
	while(i<=2) {
	 count=count1;
	 count1=count+m;
	  docname= doc1.substring(count, count1);
	 count=count1;
	 count1=count+n;
	 String docnumber1 = doc1.substring(count, count1);
	 count=count1;
	 count1=count+p;
	 doctype= doc1.substring(count, count1);
	 docnumber=Long.parseLong(docnumber1);
	 Doc doc = new Doc();
	 doc.setCompanyName(docname);
	 doc.setCompanyNumber(docnumber);
	 doc.setEventType(doctype);
	 return docRepository.save(doc);
	 //System.out.println(doc.getCompanyName());
	
	
	}
	return null; 
	
	 
}
	

	
	public Optional<Doc> getFile(Integer id){
		return docRepository.findById(id);
		
	}
	public Iterable<Doc> getFiles(){
		return docRepository.findAll();
		
	}
}
