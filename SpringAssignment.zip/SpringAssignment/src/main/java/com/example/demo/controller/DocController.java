package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Doc;
import com.example.demo.service.DocService;

@Controller
public class DocController {
  @Autowired
  private DocService docService;
   @GetMapping("/")
   public String get(Model model) {
	   List<Doc> docs = docService.getFiles();
	   model.addAttribute("docs",docs);
	   return "doc";
	  }
   @PostMapping("/uploadFiles")
   public String uploadMultipleFiles(@RequestParam("files")MultipartFile[] files) {
	for(MultipartFile file:files) {
	   docService.saveFile(file);	   
   }
   return "redirect:/";
}
}
