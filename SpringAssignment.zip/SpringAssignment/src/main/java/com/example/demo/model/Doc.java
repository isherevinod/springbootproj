package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Company_Details")
public class Doc {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
	
	private String companyName;
	private long companyNumber;
	private String eventType;
	//private Date eventDate;
	public Doc( String companyName, long companyNumber, String eventType ) {
		super();
		this.companyName = companyName;
		this.companyNumber = companyNumber;
		this.eventType = eventType;
		//this.eventDate = eventDate;
	}
	
	public void Docs(String companyName2, long size, String contentType) {
		// TODO Auto-generated constructor stub
	}
 
	public Doc() {
		super();
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public long getCompanyNumber() {
		return companyNumber;
	}
	public void setCompanyNumber(long companyNumber) {
		this.companyNumber = companyNumber;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	
	
	
	 
	
	

}
