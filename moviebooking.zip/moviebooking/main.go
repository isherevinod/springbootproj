package main

import (
	"log"
	"net"

	"google.golang.org/grpc"

	"moviebooking/proto"
	"moviebooking/server"
	"moviebooking/store"
)

func main() {
	store.InitData()

	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatal("failed to listen:", err)
	}

	grpcServer := grpc.NewServer()

	proto.RegisterUserServiceServer(grpcServer, &server.UserServer{})
	proto.RegisterMovieServiceServer(grpcServer, &server.MovieServer{})
	proto.RegisterTicketServiceServer(grpcServer, &server.TicketServer{})
	proto.RegisterAdminServiceServer(grpcServer, &server.AdminServer{})

	log.Println("gRPC running on :50051")
	grpcServer.Serve(lis)
}
