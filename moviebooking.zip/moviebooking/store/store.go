package store

import (
	"errors"
	"fmt"
)

type User struct {
	First string
	Last  string
	Email string
	Login string
	Pass  string
}

type Movie struct {
	Name      string
	Theatre   string
	Available int
}

var Users = map[string]User{}
var Movies = map[string]Movie{}
var Tickets = map[string]string{}

func InitData() {
	Movies["Inception-PVR"] = Movie{"Inception", "PVR", 5}
	Movies["Batman-IMAX"] = Movie{"Batman", "IMAX", 3}
	Movies["StrangerThings-CINEPOLLIS"] = Movie{"StrangerThings", "CINEPOLLIS", 5}
	Movies["EmilyInParis-IMAX"] = Movie{"EmilyInParis", "IMAX", 3}

}

func Register(u User) error {
	if _, exists := Users[u.Login]; exists {
		return errors.New("user already exists")
	}
	Users[u.Login] = u
	return nil
}

func Login(login, pass string) error {
	u, ok := Users[login]
	if !ok || u.Pass != pass {
		return errors.New("invalid credentials")
	}
	return nil
}

func ListMovies() []Movie {
	var res []Movie
	for _, m := range Movies {
		res = append(res, m)
	}
	return res
}

func SearchMovie(name string) []Movie {
	var res []Movie
	for _, m := range Movies {
		if m.Name == name {
			res = append(res, m)
		}
	}
	return res
}

func Book(movie, theatre string, seats int) (string, error) {
	key := fmt.Sprintf("%s-%s", movie, theatre)

	m, ok := Movies[key]
	if !ok {
		return "", errors.New("movie not found")
	}
	if m.Available < seats {
		return "", errors.New("not enough tickets")
	}

	m.Available -= seats
	Movies[key] = m

	id := fmt.Sprintf("TKT-%d", len(Tickets)+1)
	Tickets[id] = key

	return id, nil
}

func CheckStatus(movie, theatre string) string {
	key := fmt.Sprintf("%s-%s", movie, theatre)
	m := Movies[key]

	if m.Available == 0 {
		return "SOLD OUT"
	}

	return "BOOK ASAP"
}
