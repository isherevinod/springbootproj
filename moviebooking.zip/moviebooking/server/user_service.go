package server

import (
	"context"

	"moviebooking/proto"
	"moviebooking/store"
)

type UserServer struct {
	proto.UnimplementedUserServiceServer
}

func (s *UserServer) Register(ctx context.Context, r *proto.UserRegisterRequest) (*proto.UserResponse, error) {
	err := store.Register(store.User{
		First: r.FirstName,
		Last:  r.LastName,
		Email: r.Email,
		Login: r.LoginId,
		Pass:  r.Password,
	})

	if err != nil {
		return &proto.UserResponse{Message: err.Error()}, nil
	}

	return &proto.UserResponse{Message: "User registered"}, nil
}

func (s *UserServer) Login(ctx context.Context, r *proto.UserLoginRequest) (*proto.UserResponse, error) {
	err := store.Login(r.LoginId, r.Password)
	if err != nil {
		return &proto.UserResponse{Message: err.Error()}, nil
	}

	return &proto.UserResponse{Message: "Login successful"}, nil
}
