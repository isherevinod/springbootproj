package server

import (
	"context"

	"moviebooking/proto"
	"moviebooking/store"
)

type MovieServer struct {
	proto.UnimplementedMovieServiceServer
}

func (m *MovieServer) ListMovies(ctx context.Context, e *proto.Empty) (*proto.MovieList, error) {
	list := store.ListMovies()

	resp := &proto.MovieList{}
	for _, mv := range list {
		resp.Movies = append(resp.Movies, &proto.Movie{
			Name:             mv.Name,
			Theatre:          mv.Theatre,
			AvailableTickets: int32(mv.Available),
		})
	}

	return resp, nil
}

func (m *MovieServer) SearchMovie(ctx context.Context, r *proto.MovieSearchRequest) (*proto.MovieList, error) {
	list := store.SearchMovie(r.MovieName)

	resp := &proto.MovieList{}
	for _, mv := range list {
		resp.Movies = append(resp.Movies, &proto.Movie{
			Name:             mv.Name,
			Theatre:          mv.Theatre,
			AvailableTickets: int32(mv.Available),
		})
	}

	return resp, nil
}
