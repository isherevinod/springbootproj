package server

import (
	"context"

	"moviebooking/proto"
	"moviebooking/store"
)

type AdminServer struct {
	proto.UnimplementedAdminServiceServer
}

func (a *AdminServer) UpdateTicketStatus(ctx context.Context, r *proto.UpdateTicketRequest) (*proto.StatusResponse, error) {
	status := store.CheckStatus(r.MovieName, r.TheatreName)
	return &proto.StatusResponse{Status: status}, nil
}
