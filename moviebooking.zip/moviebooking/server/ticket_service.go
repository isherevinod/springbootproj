package server

import (
	"context"

	"moviebooking/proto"
	"moviebooking/store"
)

type TicketServer struct {
	proto.UnimplementedTicketServiceServer
}

func (t *TicketServer) BookTicket(ctx context.Context, r *proto.BookTicketRequest) (*proto.TicketResponse, error) {
	id, err := store.Book(r.MovieName, r.TheatreName, int(r.Seats))

	if err != nil {
		return &proto.TicketResponse{Status: err.Error()}, nil
	}

	return &proto.TicketResponse{TicketId: id, Status: "CONFIRMED"}, nil
}
